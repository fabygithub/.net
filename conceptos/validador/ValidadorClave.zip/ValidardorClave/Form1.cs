﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ValidardorClave
{
    public partial class Form1 : Form
    {
        string usuario = "Admin" ;
        int pass = 123;
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text == Convert.ToString(pass) && textBox1.Text == usuario)
            {
                MessageBox.Show("Usuario y Clave Correcta, Verificada con exito!", "Verificador", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else { 
                MessageBox.Show("Usuario o Clave incorrecta!", "Verificador", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pass = Convert.ToInt32(textBox2.Text);
            label3.Text = String.Format("La clave es {0}", pass);
            MessageBox.Show("Clave cambiada con exito. No la olvides!", "Cambiar contrasenia", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == usuario && textBox2.Text == Convert.ToString(pass))
            {
                MessageBox.Show("Acceso concendido!", "Acceso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            } else if (textBox1.Text == "" && textBox2.Text == "") { 
                MessageBox.Show("porfavor ingrese clave & usuario!", "Acceso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            else {
                MessageBox.Show("Error en datos ingresados!", "Acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
    }
}
